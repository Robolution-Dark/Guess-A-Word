let number_of_guesses = 0 ;
let correct_guess = 0;
let wrong_guess = 0;
let guess_word = ["HELLO", "LONDON", "WORLD", "LAPTOP", "MOUSE"]; //mesti huruf besar sebab banding dgn value button
let guess_word_desc = ["Greeting", "Place", "Whole", "Using now", "Rat"];
let guessed_char = []; //user guessed word
let random_word_index;

function initialize_game(){
	number_of_guesses = 0 ;
	guessed_char = [];
	correct_guess = 0;
	wrong_guess = 0;
	random_word_index = Math.floor( Math.random() * guess_word.length ) ;
	for(let string_counter = 0; string_counter < guess_word[random_word_index].length; string_counter++)
	{
		guessed_char.push("-");
	}
	document.getElementById( "new_game" ).style.display = "none";
	document.getElementById( "word" ).innerHTML = "";
	document.getElementById( "guessed_count" ).innerHTML = "";
	document.getElementById( "secret_word_text_id" ).innerHTML = guessed_char.join( "" ) ;
	document.getElementById( "desc" ).innerHTML = "Description: " + guess_word_desc[random_word_index];
	document.getElementById( "game_over" ).style.display = "none";
	document.getElementById( "new_game" ).style.display = "none";
	document.getElementById( "heart" ).src = "images/heart_5.png";
	document.getElementById( "congratulations" ).style.display = "none";
	document.getElementById( "play_again" ).style.display = "none";
	
	let letter_buttons = document.getElementsByClassName( "letter_button" ) ;
	for ( let button_index in letter_buttons )
	{
		letter_buttons[ button_index ].disabled = false;
		letter_buttons[ button_index ].style.border = "none"; //hide the hint
	}
}

function handle_button_press( pressed_button )
{
   let selected_letter = pressed_button.textContent ;

   for ( character_index in guessed_char )
   {
      if ( guess_word[random_word_index].charAt( character_index ) == selected_letter )
      {
        guessed_char[ character_index ] = selected_letter ;
		correct_guess++; 
      }
   }
	pressed_button.style.backgroundImage = "url(images/alphabet inactive.png)" ;
   	pressed_button.disabled = true;
	number_of_guesses++;
	
	if (guessed_char.indexOf("-")== -1) //secret word complete display tahniah then button new game appear
	{
		disable_all_letter();
		document.getElementById( "congratulations" ).style.display = "inline";
		document.getElementById( "play_again" ).style.display = "inline";
	}
	
	wrong_guess = number_of_guesses - correct_guess;
	
	console.log(wrong_guess);
	
	if (wrong_guess == 0)
	{
		document.getElementById( "heart" ).src = "images/heart_5.png";
	}
	else if (wrong_guess == 1)
	{
		document.getElementById( "heart" ).src = "images/heart_4.png";
	}
	else if (wrong_guess == 2)
	{
		document.getElementById( "heart" ).src = "images/heart_3.png";
	}
	else if (wrong_guess == 3)
	{
		document.getElementById( "heart" ).src = "images/heart_2.png";
	}
	else if (wrong_guess == 4)
	{
		document.getElementById( "heart" ).src = "images/heart_1.png";
	}
	else if (wrong_guess == 5)
	{
		game_over();
	}
/* 	double letter wrong guess is -1
	else if(wrong_guess == -1)
	{
		wrong_guess = 0;
	} */
	
   // The array containing the guessed characters will be converted
   // to a string with the join() method. The empty string "" as a parameter
   // specifies that nothing will be added between the strings.
	document.getElementById( "secret_word_text_id" ).innerHTML = guessed_char.join( "" ) ;
}

function hint(){
	let letter_buttons = document.getElementsByClassName( "letter_button" ) ;
	for ( let button_index in letter_buttons )
	{
		if (guess_word[random_word_index].indexOf(letter_buttons[ button_index ].textContent)>-1) //this button value ada dlm guess word ada border
		{
			letter_buttons[ button_index ].style.border = "2px solid #1D6EFF";
		}
	}
}

function game_over(){
	disable_all_letter();
	document.getElementById( "game_over" ).style.display = "inline";
	document.getElementById( "new_game" ).style.display = "inline";
	document.getElementById( "heart" ).src = "images/heart_0.png";
}

function disable_all_letter(){
	let letter_buttons = document.getElementsByClassName( "letter_button" ) ;
	for ( let button_index in letter_buttons )
	{
		letter_buttons[ button_index ].disabled = true;
	}
}